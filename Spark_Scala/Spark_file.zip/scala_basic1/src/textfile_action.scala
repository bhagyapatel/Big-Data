
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

object textfile_action{
def main(args: Array[String]){
  
  val conf = new SparkConf().setAppName("textfile_action").setMaster("local")
  val sc: SparkContext = new SparkContext(conf)
  val rdd = sc.textFile("C:/Users/LENOVO/Desktop/Simplilearn/haddep1/Spark Demo/spark_db/spark.txt")
  
  val rdd1 = rdd.map(f=>{f.split(" , ")})
  val rdd2 = rdd1.map(f => (f,1))
  
  // Count Countries name or group by countries 
  
  val rdd3 = rdd2.reduceByKey(_ + _)
  rdd2.foreach(println)

}
}