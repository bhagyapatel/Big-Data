

object loop {
def main(args: Array[String]){
   println("Welcome to the Scala worksheet")      //> Welcome to the Scala worksheet
   }
}