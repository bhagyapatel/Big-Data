
import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkContext

object parallelize_rdd_transform {
  def main(args: Array[String]){
    val spark = SparkSession.builder().appName("parallelize_rdd_transform").master("local").getOrCreate()
  
    spark.sparkContext.setLogLevel("ERROR")
    val firstrdd = spark.sparkContext.parallelize(List(("Z", 1),("A", 20),("B", 30),("C", 40),("B", 30),("B", 60)))
  
    val secondrdd = spark.sparkContext.parallelize(List(1,2,3,4,5,3,2))
    
    //Reduce
    println("RDD reduce is:"+secondrdd.reduce(_ + _))
    println("alternative Way to Reduce:" +secondrdd.reduce((a,b) => (a+b)))
    
    // count
    println("Count :" +secondrdd.count())
    
    //countByValue
    println("Count by value" +secondrdd.countByValue())
    
    //first
    println("Gives first value" +secondrdd.first())
    println("Gives first value" +firstrdd.first())
    
    //top
    println("Gives first value" +secondrdd.top(2).mkString(","))
    println("Gives first value" +firstrdd.top(2).mkString(","))
    
    //min
    println("it gives min:" + firstrdd.min())
    println("it gives min:" +secondrdd.min())
    
    //max
     println("it gives max:" + firstrdd.max())
    println("it gives max:" +secondrdd.max())
    
    // take
     println("it gives min" + firstrdd.take(2).mkString(","))
    println("it gives min" +secondrdd.take(2).mkString(","))
    
    //fold
    println("it gives count of secondrdd" + secondrdd.fold(0){
      (a,b) => val sum =  a+b
      sum })
      
      println("it count key value pair using fold :" + firstrdd.fold(("total",0)){
      (a:(String, Int), b:(String, Int)) => val sum = a._2+ b._2
      ("total",sum)
      })
      
  
    
  
    
  }
}