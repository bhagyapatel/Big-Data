import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object banking_df_market_analysis {
  def main(args: Array[String]){
    
    val spark = SparkSession.builder().appName("banking_df_market_analysis").master("local").getOrCreate()
    
    //1.	Load data and create a Spark data frame
    val df = spark.read.option("delimiter",",").option("Header","True").csv("C:/Users/LENOVO/Desktop/Simplilearn/dataset/json/banking_df.csv")
      df.show()
      
      
      //2.	Give marketing success rate (No. of people subscribed / total no. of entries) Give marketing failure rate

      val totalentry =  df.count.toDouble
      val no_of_subscribed = df.select("y").filter(col("y")==="yes").count.toDouble
      val no_of_failure = df.select("y").filter(col("y")==="no").count.toDouble
      
      
      val success_rate = no_of_subscribed/totalentry*100
      val failure_rate = no_of_failure/totalentry*100
      
      //3. Give the maximum, mean, and minimum age of the average targeted customer

        df.select(mean(df("age")),max(df("age")),min(df("age"))).show()
        
        
        // 4.Check the quality of customers by checking average balance, median balance of customers
              df.createOrReplaceTempView("banking")
               spark.sql("select avg(balance) as avg_balance, PERCENTILE_APROX(balance,0.5) as median_balance from banking").show()

        // 5. Check if age matters in marketing subscription for deposit
              spark.sql("select age, count(*) from banking where y ='yes' group by age order by count(*) desc").show()
      
      // 6.Check if marital status mattered for a subscription to deposit
           spark.sql("select marital, count(*) from banking where y ='yes' group by marital order by count(*) desc").show()
      
      // 7. Check if age and marital status together mattered for a subscription to deposit scheme
           spark.sql("select marital,age, count(*) from banking where y ='yes' group by marital,age order by count(*) desc").show
           
      // 8.	Do feature engineering for the bank and find the right age effect on the campaign.
           
           import spark.implicits._
           val new_df = df.withColumn("age_cat",when($"age"<25,"young")
               .otherwise(when($"age">60,"old").otherwise("mid-age")))
               
            // Get Column in tree format   
            new_df.printSchema
            
            //  Show age Category who will take subscription
            new_df.groupBy("age_cat","y").count.show()
            
            // show top age category will are subscribing
            new_df.groupBy("age_cat","y").count.sort('count.desc).show()


  
      
  

  }
}