
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.avg

object manual_df {
  def main(args: Array[String]){
  
  val spark = SparkSession.builder().appName("Manual_Create_Data").master("local").getOrCreate()
  
  //Create Dataframe Manually 
  val df = spark.createDataFrame(Seq((28,"bhagya","Ahembadad"),(25,"hirakshi","Ahmedabad"),(30,"nirmi","rajkot"),(26,"somya","pune"),(27,"divya","mumbai"),(22,"sanchi","Rajasthan"),(29,"Tithi","Ahmedabad")))
   .toDF("Age","Name","City")
   
   //Avg age par city
   val df1 = df.groupBy("city").agg(avg("age"))
   df.show()
   
   //Distinct City in Dataframe
   df.groupBy("city").count().show()
   
   //Data of particular City
  df.select("Name").filter("city == 'Ahembadad'").show()
  
  
  
  
  
   
   
  }

}