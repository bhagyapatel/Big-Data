
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.Encoder
//import org.apache.spark.sql.SparkContext
import org.apache.spark.sql.SQLImplicits

object df_to_dataset {
  def main(args: Array[String]){
    val spark = SparkSession.builder().appName("DF_to_Dataset").master("local").getOrCreate()
    
   
  final case class Person(name: String, age: Long)
  val path = "C:/Users/LENOVO/Desktop/Simplilearn/dataset/json/people.json"
  
  val df = spark.read.option("Header","True")
    .json("C:/Users/LENOVO/Desktop/Simplilearn/dataset/json/people.json")
    
    
  //val caseClassDS = Seq(Person("Andy", 32)).toDS()
  //val peopleDS = spark.read.schema(implicitly[Encoder[Person]].schema).json(path).as[Person]
  //peopleDS.show()
  
  
    
    //df.as[Person]
  
  //val caseClassDS = Seq(Person("Andy", 32))
   
 
  }
}