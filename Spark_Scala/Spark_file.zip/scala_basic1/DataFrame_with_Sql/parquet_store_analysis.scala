
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType



object parquet_store_analysis {
  def main(args: Array[String]){
    
    val spark = SparkSession.builder().appName("Parquet_Store_Analysis").master("local").getOrCreate()
    val df = spark.read.option("Header","True").parquet("C:/Users/LENOVO/Desktop/Simplilearn/dataset/parquet/abc.parquet")
    //df.show()
    
    import spark.implicits._
    
    
    // Find Distinct Country
    df.select("Country").distinct().show()
    
    // Unique Payment Type 
    df.select("Payment_Type").distinct().show()
    
    //Count Frequency of Payment Type
    df.groupBy("Payment_Type").count().show()
    
    // Cities which have purchase more 3000
     df.selectExpr("City", "cast(Price AS INT)price").filter($"price" > 3000).show()
    
   // df.selectExpr("Country").groupBy("Country").agg(sum(df("cast(Price AS INT"))).show()
    
   
    val dff = df.selectExpr("Product","cast(Price AS INT)price", "Payment_Type", "City","State", "Country")
    //dff.show()
    
    //Find Top 5 Higher Purchase Country
    dff.groupBy("Country").agg(sum(dff("price"))).show()
    dff.groupBy("Country").agg(sum(dff("price")).alias("max_sell")).orderBy($"max_sell".desc).show(5)
    
    //Find Top 5 Countries which has Purchase low
    dff.groupBy("Country").agg(sum(dff("price")).alias("low_sell")).orderBy($"low_sell").show(5)
    
   //Find 5 Stable Countries
    dff.groupBy("Country").agg(avg(dff("price")).alias("stable_sell")).orderBy($"stable_sell").show(5)
    
    //ALL Countries min,avg,max, sum purchase
    dff.groupBy("Country").agg(min(dff("price")),avg(dff("price")),max(dff("price")),sum(dff("price"))).show(5)
    
    
    //Which Product Has highest sell
    dff.groupBy("product").agg(sum(dff("price")).alias("prod_highest_sell")).orderBy($"prod_highest_sell".desc).show(1)
    
    
    //Which Product Has low sell
    dff.groupBy("product").agg(sum(dff("price")).alias("prod_lowest_sell")).orderBy($"prod_lowest_sell").show(1)

    
    
    
  }
  
}