
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf
object import_json_operation {
  def main(args: Array[String]){
    
    
    val spark = SparkSession.builder()
    .appName("json_db_operation")
    .master("local")
    .getOrCreate()
    
    
    val df = spark.read.option("Header","True")
    .json("C:/Users/LENOVO/Desktop/Simplilearn/dataset/json/temperatures.json")
    df.show()
    
    // register df with view
    df.createOrReplaceTempView("jfile")
    
    // Register UDF
    spark.udf.register("fname",(degcel:Double) => ((degcel * 9.0/ 5.0)+32))
    
    // Extraction data from Temporary View File
  val a = udf((degcel: Double) => ((degcel * 9.0/5.0)+32))
  spark.sql("select * from jfile").show()
  spark.sql("select city, a(avgHigh) as avghigh, a(avgLow) as avglow from jfile").show()
  
    
    
    
    
    
  }
}